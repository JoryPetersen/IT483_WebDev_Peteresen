using System;

namespace Lab2
	{ 
	class Program
		{
        	public static void main(String[] args)
			{
			Console.WriteLine("Single Prescription(1) or Non-Prescription(2)");

			String userIn1 = Console.ReadLine();
			
			if (userIn1 == '1')
				{
				Console.WriteLine("Anti-glare (1) or Brown tint (2)");
				
				String userIn2 = Console.ReadLine();
				if (userIn2 == '1')
					{
					Console.WritLine("Total: $52.50");
					}
				else if (userInt2 == '2')
					{
					Console.WriteLine("Total: $49.99");
					}
				else
					{
					Console.WriteLine("Total: $40.00");
					}
				}

			else if (userIn1 == '2')
				{
				Console.WriteLine("Total: $25.00");
				}

			else if (userIn1 != '1' || userIn1 != '2')
				{
				Console.WriteLine("Please use either (1) or (2)");
				}
			}
		}
	}
	